var start=new Date().getTime();
var canvas=document.querySelector('canvas');
canvas.width = window.innerWidth-2;
canvas.height = window.innerHeight-50;
var c=canvas.getContext('2d');

var mouse={
    x:undefined,
    y:undefined,
    dx:undefined,
    dy:undefined
}
window.addEventListener('mousemove',function(event){
       mouse.x=event.x;
       mouse.y=event.y;
       mouse.dx=event.movementX;
       mouse.dy=event.movementY;
})
window.addEventListener('resize',function(){
    canvas.width = window.innerWidth-2;
    canvas.height = window.innerHeight-50;
})
var colorArray=[
    '#ffff00','#ff3300','#003399','#ffc34d','#990000'
];
var count=0;

var time=setInterval(function(){
    var now=new Date().getTime();
    var distance=Math.floor((now-start)/1000);
    if(distance>59)
    {
        window.open("Lost.html","_self");
    }
    document.getElementById("timer").innerHTML="<b> &nbsp&nbsp&nbsp TIMER:&nbsp&nbsp&nbsp"+distance+"</b>";
},500);

function Circle(x, y, dx, dy, radius){
    this.x=x;
    this.y=y;
    this.dx=dx;
    this.dy=dy;
    this.radius=radius;
    this.color=colorArray[Math.floor(Math.random()*colorArray.length)];
    
    this.draw=function(){
        c.beginPath();
        c.arc(this.x,this.y,this.radius,0,2*Math.PI,false);
        c.strokeStyle ='black';
        c.stroke();  
        c.fillStyle=colorArray[Math.floor(Math.random()*colorArray.length)];
        c.fill();
        c.closePath();
    }

    this.update=function(){
        if(this.x+this.radius >= canvas.width || this.x-this.radius <= 0){
            this.dx=-this.dx;
        }
        if(this.y-this.radius <= 0){
            this.dy=-this.dy;
        }
        if(this.y+this.radius>=pointer.y && (this.x+this.radius>=pointer.x-2.5 && this.x-this.radius<=pointer.x+152.5) && this.y+this.radius<=pointer.y+15){
            this.dy=-this.dy;
            this.dx=(this.dx+mouse.dx)/2;
        }
        if(this.y>canvas.height)
        {
            window.open("Lost.html","_self");
        }
        this.y+=this.dy;
        this.x+=this.dx;

        abcx=this.x;
        abcy=this.y;
        abcr=this.radius;
        this.draw();
    }
}
function Brick(x,y,hei,wid,color,dx,status,distance){
    this.x=x;
    this.y=y;
    this.height=hei;
    this.width=wid;
    this.color=color;
    this.dx=dx;
    this.status=status;
    this.distance=distance;
    this.draw=function(){
        c.beginPath();
        c.fillRect(this.x,this.y,this.width,this.height);
        c.strokeStyle='black';
        c.stroke();
        c.fillStyle=this.color;
        c.fill();
        c.closePath();
    }
    this.update=function(){
        if(this.x<=0 ||this.x+50>=canvas.width)
         this.dx=-this.dx; 
        
        this.distance=Math.sqrt(Math.pow((this.x+25-abcx),2)+Math.pow((this.y+25-abcy),2));
         if(this.distance<=30+abcr){           
            this.status=0;
            count++;
            if(count==50)
               window.open("new.html","_self");
            document.getElementById("score").innerHTML="<b> &nbsp&nbsp YOUR SCORE:&nbsp&nbsp&nbsp"+count+"</b>";
        } 
        this.x+=this.dx; 
        
        this.draw();
    }

}
function Rectangle(x,y,width,height,color)
{
    this.x=x;
    this.y=y;
    this.width=width;
    this.height=height;
    this.color=color;
    this.draw=function(){
        c.beginPath();
        c.fillRect(this.x,this.y,this.width,this.height);
        c.strokeStyle="brown";
        c.stroke();
        c.fillStyle="yellow";
        c.fill();
        c.closePath();

        c.beginPath();
        c.arc(this.x+5.5,this.y+7.5,(this.height/2),0,2*Math.PI,false);
        c.strokeStyle ='brown';
        c.stroke();  
        c.fillStyle=this.color;
        c.fill();
        c.closePath();

        c.beginPath();
        c.arc(this.x+144.5,this.y+7.5,(this.height/2),0,2*Math.PI,false);
        c.strokeStyle ='brown';
        c.stroke();  
        c.fillStyle=this.color;
        c.fill();
        c.closePath();
    }
    this.update=function(){
        this.x=mouse.x-75;
        this.draw();
    }
}

var circleArray=[];
for(var i=0;i<1;i++){
    var radius=10;
    var x=(Math.random()*(canvas.width-2*radius))+radius;
    var y=50;
    var dx=5;
    var dy=6;

    circleArray.push(new Circle(x,y,dx,dy,radius));
}
var brickArray=[];
for(var i=0;i<50;i++){
    var x=Math.random()*(canvas.width-50);
    var y=Math.random()*(100)+10;
    var hei=50;
    var wid=50;
    var dx=(Math.random()-0.5)*5;
    var color=colorArray[Math.floor(Math.random()*colorArray.length)];
    var status=1;
    var distance=undefined;
    brickArray.push(new Brick(x,y,hei,wid,color,dx,status,distance));
}


var pointer={
    x:300,
    y:(canvas.height-15)
};
pointer=new Rectangle(pointer.x,pointer.y,150,15,'red');


function animate(){
    requestAnimationFrame(animate);
    c.clearRect(0,0,canvas.width,canvas.height);
    for(var i=0;i<circleArray.length;i++){
        circleArray[i].update();
    }
    pointer.update(); 
    for(var i=0;i<brickArray.length;i++){
        if(brickArray[i].status==1)
          brickArray[i].update();
    }  
}
animate();
/////////////////////////////////////////////////////////////////////////////////////////